package com.rahya.rahygram.viewmodel

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rahya.rahygram.BuildConfig
import com.rahya.rahygram.data.firebase.FirebasePhoneAuthCoordinator
import com.rahya.rahygram.data.model.User
import com.rahya.rahygram.data.repository.ServiceLocator
import com.rahya.rahygram.notifications.FcmTokenStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class AuthUiState(
    val identifier: String = "",
    val otp: String = "",
    val codeRequested: Boolean = false,
    val useEmail: Boolean = false,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class AuthViewModel : ViewModel() {
    private val repository = ServiceLocator.messagingRepository
    private val phoneAuthCoordinator = FirebasePhoneAuthCoordinator()
    private val mutableState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = mutableState.asStateFlow()
    val currentUser: StateFlow<User?> = repository.currentUser.stateIn(viewModelScope, SharingStarted.Eagerly, null)

    fun setIdentifier(value: String) {
        mutableState.value = mutableState.value.copy(identifier = value)
    }

    fun setOtp(value: String) {
        mutableState.value = mutableState.value.copy(otp = value.take(6))
    }

    fun toggleLoginMode() {
        mutableState.value = mutableState.value.copy(useEmail = !mutableState.value.useEmail, codeRequested = false)
    }

    fun requestOtp(activity: Activity?) = viewModelScope.launch {
        mutableState.value = mutableState.value.copy(isLoading = true)
        val state = mutableState.value
        runCatching {
            if (BuildConfig.USE_FIREBASE_BACKEND && !state.useEmail) {
                requireNotNull(activity) { "Activity is required for phone OTP." }
                phoneAuthCoordinator.requestCode(
                    activity = activity,
                    phoneNumber = state.identifier,
                    onCodeSent = {
                        mutableState.value = mutableState.value.copy(
                            isLoading = false,
                            codeRequested = true,
                            errorMessage = null
                        )
                    },
                    onVerifiedInstantly = { credential ->
                        phoneAuthCoordinator.signInWithCredential(credential)
                        repository.signInWithOtp(state.identifier, state.otp)
                        FcmTokenStore.latestToken?.let { token -> repository.syncFcmToken(token) }
                    },
                    onError = { error ->
                        mutableState.value = mutableState.value.copy(
                            isLoading = false,
                            errorMessage = error.message
                        )
                    }
                )
            } else {
                repository.requestOtp(state.identifier)
                mutableState.value = mutableState.value.copy(
                    isLoading = false,
                    codeRequested = true,
                    errorMessage = null
                )
            }
        }.onFailure { error ->
            mutableState.value = mutableState.value.copy(isLoading = false, errorMessage = error.message)
        }
    }

    fun verify() = viewModelScope.launch {
        mutableState.value = mutableState.value.copy(isLoading = true)
        val state = mutableState.value
        runCatching {
            if (BuildConfig.USE_FIREBASE_BACKEND && !state.useEmail) {
                phoneAuthCoordinator.verifyCode(state.otp)
            }
            repository.signInWithOtp(state.identifier, state.otp)
            FcmTokenStore.latestToken?.let { repository.syncFcmToken(it) }
        }.onSuccess {
            mutableState.value = mutableState.value.copy(isLoading = false, errorMessage = null)
        }.onFailure { error ->
            mutableState.value = mutableState.value.copy(isLoading = false, errorMessage = error.message)
        }
    }
}
