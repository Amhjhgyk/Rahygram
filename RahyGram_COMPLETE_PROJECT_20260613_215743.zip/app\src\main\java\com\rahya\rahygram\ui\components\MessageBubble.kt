package com.rahya.rahygram.ui.components

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rahya.rahygram.R
import com.rahya.rahygram.data.model.DeliveryState
import com.rahya.rahygram.data.model.Message
import com.rahya.rahygram.data.model.MessageType

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageBubble(
    message: Message,
    isMine: Boolean,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bubbleShape = if (isMine) {
        RoundedCornerShape(topStart = 22.dp, topEnd = 8.dp, bottomStart = 22.dp, bottomEnd = 22.dp)
    } else {
        RoundedCornerShape(topStart = 8.dp, topEnd = 22.dp, bottomStart = 22.dp, bottomEnd = 22.dp)
    }
    val color = if (isMine) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
    val contentColor = if (isMine) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface

    Row(
        modifier = modifier.padding(horizontal = 16.dp, vertical = 5.dp),
        horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 292.dp)
                .combinedClickable(onClick = {}, onLongClick = onLongPress),
            shape = bubbleShape,
            color = color,
            contentColor = contentColor,
            tonalElevation = 2.dp
        ) {
            Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                if (message.type == MessageType.Text) {
                    Text(message.body, style = MaterialTheme.typography.bodyLarge)
                } else {
                    AttachmentPreview(message)
                }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (message.editedAtEpochMillis != null) {
                        Text(stringResource(R.string.edited), style = MaterialTheme.typography.labelSmall)
                    }
                    if (isMine) {
                        Text(deliveryMark(message.deliveryState), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                    if (message.reactions.isNotEmpty()) {
                        Text(message.reactions.values.joinToString(" "), style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }
    }
}

@Composable
private fun AttachmentPreview(message: Message) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(
            imageVector = when (message.type) {
                MessageType.Image -> Icons.Rounded.Image
                MessageType.Voice -> Icons.Rounded.Mic
                MessageType.File, MessageType.Text -> Icons.Rounded.AttachFile
            },
            contentDescription = null,
            modifier = Modifier.size(22.dp)
        )
        Column {
            Text(
                text = when (message.type) {
                    MessageType.Image -> stringResource(R.string.image_message)
                    MessageType.Voice -> stringResource(R.string.voice_note)
                    MessageType.File -> stringResource(R.string.file_message)
                    MessageType.Text -> message.body
                },
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.size(2.dp))
            Text(message.body, style = MaterialTheme.typography.labelMedium)
        }
    }
}

private fun deliveryMark(state: DeliveryState): String = when (state) {
    DeliveryState.Sending -> "..."
    DeliveryState.Sent -> "✓"
    DeliveryState.Delivered -> "✓✓"
    DeliveryState.Seen -> "●✓"
}
