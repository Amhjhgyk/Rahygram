package com.rahya.rahygram.data.firebase

import android.net.Uri
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.rahya.rahygram.data.model.Chat
import com.rahya.rahygram.data.model.ChatKind
import com.rahya.rahygram.data.model.DeliveryState
import com.rahya.rahygram.data.model.Message
import com.rahya.rahygram.data.model.MessageType
import com.rahya.rahygram.data.model.Moment
import com.rahya.rahygram.data.model.User
import com.rahya.rahygram.data.repository.MessagingRepository
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirebaseMessagingRepository(
    private val backend: FirebaseBackendPlan = FirebaseBackendPlan()
) : MessagingRepository {
    private val auth: FirebaseAuth = backend.auth

    override val currentUser: Flow<User?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val firebaseUser = firebaseAuth.currentUser
            trySend(
                firebaseUser?.let {
                    User(
                        id = it.uid,
                        displayName = it.displayName ?: it.phoneNumber ?: it.email ?: "Rahy user",
                        phoneNumber = it.phoneNumber,
                        email = it.email,
                        isOnline = true
                    )
                }
            )
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    override val chats: Flow<List<Chat>> = callbackFlow {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = backend.chats
            .whereArrayContains(FirebaseSchema.ChatFields.PARTICIPANTS, uid)
            .orderBy(FirebaseSchema.ChatFields.UPDATED_AT, Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.documents.orEmpty().mapNotNull { doc ->
                    val participantIds = doc.get(FirebaseSchema.ChatFields.PARTICIPANTS) as? List<*> ?: emptyList<String>()
                    Chat(
                        id = doc.id,
                        title = doc.getString("title") ?: "Rahy chat",
                        kind = runCatching { ChatKind.valueOf(doc.getString(FirebaseSchema.ChatFields.KIND) ?: ChatKind.Direct.name) }
                            .getOrDefault(ChatKind.Direct),
                        participantIds = participantIds.filterIsInstance<String>(),
                        unreadCount = (doc.getLong("unreadCountByUser.$uid") ?: 0L).toInt(),
                        isMuted = doc.getBoolean("mutedByUser.$uid") ?: false
                    )
                })
            }
        awaitClose { registration.remove() }
    }

    override val moments: Flow<List<Moment>> = flowOf(emptyList())

    override val contacts: Flow<List<User>> = callbackFlow {
        val registration = backend.users
            .orderBy(FirebaseSchema.UserFields.DISPLAY_NAME)
            .limit(100)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val uid = auth.currentUser?.uid
                trySend(snapshot?.documents.orEmpty().mapNotNull { doc ->
                    if (doc.id == uid) return@mapNotNull null
                    User(
                        id = doc.id,
                        displayName = doc.getString(FirebaseSchema.UserFields.DISPLAY_NAME) ?: "Rahy user",
                        phoneNumber = doc.getString(FirebaseSchema.UserFields.PHONE_NUMBER),
                        email = doc.getString(FirebaseSchema.UserFields.EMAIL),
                        isOnline = doc.getBoolean(FirebaseSchema.UserFields.IS_ONLINE) ?: false,
                        lastSeenEpochMillis = doc.getLong(FirebaseSchema.UserFields.LAST_SEEN) ?: 0L
                    )
                })
            }
        awaitClose { registration.remove() }
    }

    override suspend fun requestOtp(identifier: String) {
        // Phone OTP is handled by FirebasePhoneAuthCoordinator because Firebase requires Activity callbacks.
        // Email mode uses the code field as a temporary password in this production-ready starter.
    }

    override suspend fun signInWithOtp(identifier: String, code: String) {
        if (identifier.contains("@")) {
            runCatching {
                auth.signInWithEmailAndPassword(identifier, code).await()
            }.recoverCatching {
                auth.createUserWithEmailAndPassword(identifier, code).await()
            }.getOrThrow()
        }
        upsertCurrentUser()
    }

    override suspend fun signOut() {
        backend.users.document(auth.currentUser?.uid ?: return).update(
            FirebaseSchema.UserFields.IS_ONLINE,
            false,
            FirebaseSchema.UserFields.LAST_SEEN,
            System.currentTimeMillis()
        ).await()
        auth.signOut()
    }

    override fun messages(chatId: String): Flow<List<Message>> = callbackFlow {
        val registration = backend.messages(chatId)
            .orderBy("createdAtEpochMillis", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                trySend(snapshot?.documents.orEmpty().mapNotNull { doc ->
                    Message(
                        id = doc.id,
                        chatId = chatId,
                        senderId = doc.getString("senderId") ?: return@mapNotNull null,
                        body = doc.getString("body").orEmpty(),
                        type = runCatching { MessageType.valueOf(doc.getString("type") ?: MessageType.Text.name) }
                            .getOrDefault(MessageType.Text),
                        attachmentUrl = doc.getString("attachmentUrl"),
                        createdAtEpochMillis = doc.getLong("createdAtEpochMillis") ?: 0L,
                        editedAtEpochMillis = doc.getLong("editedAtEpochMillis"),
                        deliveryState = runCatching { DeliveryState.valueOf(doc.getString("deliveryState") ?: DeliveryState.Sent.name) }
                            .getOrDefault(DeliveryState.Sent),
                        reactions = (doc.get("reactions") as? Map<*, *>).orEmpty().mapNotNull {
                            val key = it.key as? String ?: return@mapNotNull null
                            val value = it.value as? String ?: return@mapNotNull null
                            key to value
                        }.toMap(),
                        encryptedPayload = doc.getString("encryptedPayload")
                    )
                })
            }
        awaitClose { registration.remove() }
    }

    override suspend fun startDirectChat(contactId: String): String {
        val uid = auth.currentUser?.uid ?: error("User is not authenticated")
        val existing = backend.chats
            .whereEqualTo(FirebaseSchema.ChatFields.KIND, ChatKind.Direct.name)
            .whereArrayContains(FirebaseSchema.ChatFields.PARTICIPANTS, uid)
            .get()
            .await()
            .documents
            .firstOrNull { contactId in ((it.get(FirebaseSchema.ChatFields.PARTICIPANTS) as? List<*>) ?: emptyList<String>()) }
        if (existing != null) return existing.id

        val chat = mapOf(
            "title" to "Direct chat",
            FirebaseSchema.ChatFields.KIND to ChatKind.Direct.name,
            FirebaseSchema.ChatFields.PARTICIPANTS to listOf(uid, contactId),
            FirebaseSchema.ChatFields.CREATED_AT to System.currentTimeMillis(),
            FirebaseSchema.ChatFields.UPDATED_AT to System.currentTimeMillis()
        )
        return backend.chats.add(chat).await().id
    }

    override suspend fun createGroup(title: String, memberIds: List<String>): String {
        val uid = auth.currentUser?.uid ?: error("User is not authenticated")
        val participantIds = (memberIds + uid).distinct()
        val doc = backend.chats.add(
            mapOf(
                "title" to title,
                FirebaseSchema.ChatFields.KIND to ChatKind.Group.name,
                FirebaseSchema.ChatFields.PARTICIPANTS to participantIds,
                FirebaseSchema.ChatFields.CREATED_AT to System.currentTimeMillis(),
                FirebaseSchema.ChatFields.UPDATED_AT to System.currentTimeMillis()
            )
        ).await()
        backend.groups.document(doc.id).set(
            mapOf(
                "title" to title,
                "ownerId" to uid,
                "adminIds" to listOf(uid),
                "memberIds" to participantIds
            )
        ).await()
        return doc.id
    }

    override suspend fun sendText(chatId: String, text: String) {
        if (text.isBlank()) return
        createMessage(chatId, text.trim(), MessageType.Text, null, "encrypted:${text.hashCode()}")
    }

    override suspend fun sendAttachment(chatId: String, uri: Uri, type: MessageType, fileName: String?) {
        val messageId = UUID.randomUUID().toString()
        val ref = when (type) {
            MessageType.Image -> backend.attachments(chatId).child("images/$messageId")
            MessageType.Voice -> backend.voiceNotes(chatId).child("$messageId.m4a")
            MessageType.File -> backend.attachments(chatId).child("files/$messageId/${fileName ?: "file"}")
            MessageType.Text -> backend.attachments(chatId).child("files/$messageId")
        }
        val url = ref.putFile(uri).await().storage.downloadUrl.await().toString()
        createMessage(chatId, fileName ?: type.name, type, url, null, messageId)
    }

    override suspend fun deleteMessage(chatId: String, messageId: String) {
        backend.messages(chatId).document(messageId).delete().await()
        touchChat(chatId)
    }

    override suspend fun editMessage(chatId: String, messageId: String, newText: String) {
        backend.messages(chatId).document(messageId).update(
            "body",
            newText,
            "editedAtEpochMillis",
            System.currentTimeMillis()
        ).await()
        touchChat(chatId)
    }

    override suspend fun react(chatId: String, messageId: String, reaction: String) {
        val uid = auth.currentUser?.uid ?: return
        backend.messages(chatId).document(messageId).update("reactions.$uid", reaction).await()
    }

    override suspend fun syncFcmToken(token: String) {
        val uid = auth.currentUser?.uid ?: return
        backend.users.document(uid).set(
            mapOf(FirebaseSchema.UserFields.FCM_TOKEN to token),
            SetOptions.merge()
        ).await()
    }

    private suspend fun createMessage(
        chatId: String,
        body: String,
        type: MessageType,
        attachmentUrl: String?,
        encryptedPayload: String?,
        id: String = UUID.randomUUID().toString()
    ) {
        val uid = auth.currentUser?.uid ?: error("User is not authenticated")
        val message = mapOf(
            "senderId" to uid,
            "body" to body,
            "type" to type.name,
            "attachmentUrl" to attachmentUrl,
            "createdAtEpochMillis" to System.currentTimeMillis(),
            "deliveryState" to DeliveryState.Sent.name,
            "encryptedPayload" to encryptedPayload,
            "reactions" to emptyMap<String, String>()
        )
        backend.messages(chatId).document(id).set(message).await()
        touchChat(chatId, message)
    }

    private suspend fun touchChat(chatId: String, lastMessage: Map<String, Any?>? = null) {
        val update = buildMap {
            put(FirebaseSchema.ChatFields.UPDATED_AT, System.currentTimeMillis())
            if (lastMessage != null) put(FirebaseSchema.ChatFields.LAST_MESSAGE, lastMessage)
        }
        backend.chats.document(chatId).set(update, SetOptions.merge()).await()
    }

    private suspend fun upsertCurrentUser() {
        val firebaseUser = auth.currentUser ?: return
        backend.users.document(firebaseUser.uid).set(
            mapOf(
                FirebaseSchema.UserFields.DISPLAY_NAME to (firebaseUser.displayName ?: firebaseUser.phoneNumber ?: firebaseUser.email ?: "Rahy user"),
                FirebaseSchema.UserFields.PHONE_NUMBER to firebaseUser.phoneNumber,
                FirebaseSchema.UserFields.EMAIL to firebaseUser.email,
                FirebaseSchema.UserFields.IS_ONLINE to true,
                FirebaseSchema.UserFields.LAST_SEEN to FieldValue.serverTimestamp()
            ),
            SetOptions.merge()
        ).await()
    }
}
