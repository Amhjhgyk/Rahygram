package com.rahya.rahygram.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.rahya.rahygram.ui.screens.auth.AuthScreen
import com.rahya.rahygram.ui.screens.chat.ChatScreen
import com.rahya.rahygram.ui.screens.home.HomeScreen
import com.rahya.rahygram.ui.screens.settings.SettingsScreen
import com.rahya.rahygram.viewmodel.AuthViewModel
import com.rahya.rahygram.viewmodel.ChatViewModel
import com.rahya.rahygram.viewmodel.SettingsViewModel

private object Routes {
    const val Auth = "auth"
    const val Home = "home"
    const val Settings = "settings"
    const val Chat = "chat/{chatId}"
    fun chat(chatId: String) = "chat/$chatId"
}

@Composable
fun RahyNavHost() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = viewModel()
    val chatViewModel: ChatViewModel = viewModel()
    val settingsViewModel: SettingsViewModel = viewModel()
    val currentUser by authViewModel.currentUser.collectAsState()
    val start = if (currentUser == null) Routes.Auth else Routes.Home

    NavHost(navController = navController, startDestination = start) {
        composable(Routes.Auth) {
            AuthScreen(
                viewModel = authViewModel,
                onAuthenticated = {
                    navController.navigate(Routes.Home) {
                        popUpTo(Routes.Auth) { inclusive = true }
                    }
                }
            )
        }
        composable(Routes.Home) {
            HomeScreen(
                viewModel = chatViewModel,
                onOpenChat = { navController.navigate(Routes.chat(it)) },
                onOpenSettings = { navController.navigate(Routes.Settings) }
            )
        }
        composable(
            route = Routes.Chat,
            arguments = listOf(navArgument("chatId") { type = NavType.StringType })
        ) { entry ->
            val chatId = entry.arguments?.getString("chatId").orEmpty()
            ChatScreen(
                chatId = chatId,
                viewModel = chatViewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable(Routes.Settings) {
            SettingsScreen(
                viewModel = settingsViewModel,
                onBack = { navController.popBackStack() },
                onLoggedOut = {
                    navController.navigate(Routes.Auth) {
                        popUpTo(Routes.Home) { inclusive = true }
                    }
                }
            )
        }
    }
}
