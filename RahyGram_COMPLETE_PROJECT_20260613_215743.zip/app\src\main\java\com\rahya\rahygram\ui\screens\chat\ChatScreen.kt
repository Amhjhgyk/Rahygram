package com.rahya.rahygram.ui.screens.chat

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AttachFile
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.rahya.rahygram.R
import com.rahya.rahygram.core.media.VoiceRecorder
import com.rahya.rahygram.data.model.MessageType
import com.rahya.rahygram.ui.components.MessageBubble
import com.rahya.rahygram.viewmodel.ChatViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    chatId: String,
    viewModel: ChatViewModel,
    onBack: () -> Unit
) {
    val chats by viewModel.chats.collectAsState()
    val chat = chats.firstOrNull { it.id == chatId }
    val messages by viewModel.messages(chatId).collectAsState(initial = emptyList())
    val context = LocalContext.current
    val voiceRecorder = remember(context) { VoiceRecorder(context) }
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var selectedMessageId by remember { mutableStateOf<String?>(null) }
    var editingMessageId by remember { mutableStateOf<String?>(null) }
    var editText by remember { mutableStateOf("") }
    var isRecording by remember { mutableStateOf(false) }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) viewModel.sendAttachment(chatId, uri, MessageType.Image, "image")
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.sendAttachment(chatId, uri, MessageType.File, "file")
    }
    val recordPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            voiceRecorder.start()
            isRecording = true
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
                    }
                },
                title = {
                    Column {
                        Text(chat?.title ?: stringResource(R.string.chats), fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.online), style = MaterialTheme.typography.labelSmall)
                    }
                }
            )
        },
        bottomBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                IconButton(onClick = { filePicker.launch(arrayOf("*/*")) }) {
                    Icon(Icons.Rounded.AttachFile, contentDescription = stringResource(R.string.attach_file))
                }
                IconButton(onClick = { imagePicker.launch("image/*") }) {
                    Icon(Icons.Rounded.Image, contentDescription = stringResource(R.string.attach_image))
                }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text(stringResource(R.string.message_hint)) },
                    shape = RoundedCornerShape(22.dp),
                    maxLines = 4
                )
                IconButton(onClick = {
                    if (isRecording) {
                        voiceRecorder.stop()?.let { uri ->
                            viewModel.sendAttachment(chatId, uri, MessageType.Voice, "voice.m4a")
                        }
                        isRecording = false
                    } else {
                        val granted = ContextCompat.checkSelfPermission(
                            context,
                            Manifest.permission.RECORD_AUDIO
                        ) == PackageManager.PERMISSION_GRANTED
                        if (granted) {
                            voiceRecorder.start()
                            isRecording = true
                        } else {
                            recordPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                }) {
                    Icon(
                        Icons.Rounded.Mic,
                        contentDescription = stringResource(R.string.voice_note),
                        tint = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                    )
                }
                IconButton(
                    onClick = {
                        viewModel.sendText(chatId, input)
                        input = ""
                    }
                ) {
                    Icon(Icons.Rounded.Send, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            state = listState
        ) {
            items(messages, key = { it.id }) { message ->
                MessageBubble(
                    message = message,
                    isMine = message.senderId == "u-me",
                    onLongPress = { selectedMessageId = message.id },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }

    selectedMessageId?.let { messageId ->
        val selectedMessage = messages.firstOrNull { it.id == messageId }
        AlertDialog(
            onDismissRequest = { selectedMessageId = null },
            title = { Text(stringResource(R.string.message_actions)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(stringResource(R.string.message_actions_body))
                    if (selectedMessage?.senderId == "u-me") {
                        TextButton(
                            onClick = {
                                editingMessageId = messageId
                                editText = selectedMessage.body
                                selectedMessageId = null
                            }
                        ) {
                            Text(stringResource(R.string.edit))
                        }
                        TextButton(
                            onClick = {
                                viewModel.delete(chatId, messageId)
                                selectedMessageId = null
                            }
                        ) {
                            Text(stringResource(R.string.delete))
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.react(chatId, messageId, "\u2665")
                        selectedMessageId = null
                    }
                ) { Text(stringResource(R.string.react)) }
            },
            dismissButton = {
                TextButton(onClick = { selectedMessageId = null }) {
                    Text(stringResource(R.string.close))
                }
            }
        )
    }

    editingMessageId?.let { messageId ->
        AlertDialog(
            onDismissRequest = { editingMessageId = null },
            title = { Text(stringResource(R.string.edit_message)) },
            text = {
                OutlinedTextField(
                    value = editText,
                    onValueChange = { editText = it },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 5,
                    shape = RoundedCornerShape(18.dp)
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.edit(chatId, messageId, editText)
                        editingMessageId = null
                    }
                ) { Text(stringResource(R.string.save)) }
            },
            dismissButton = {
                TextButton(onClick = { editingMessageId = null }) {
                    Text(stringResource(R.string.cancel))
                }
            }
        )
    }
}
