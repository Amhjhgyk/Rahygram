package com.rahya.rahygram.data.firebase

data class VoiceCallPlan(
    val callId: String,
    val chatId: String,
    val callerId: String,
    val receiverIds: List<String>,
    val signalingCollection: String = "calls"
)

object VoiceCallSignalingSchema {
    const val CALLS = "calls"
    const val OFFERS = "offers"
    const val ANSWERS = "answers"
    const val ICE_CANDIDATES = "iceCandidates"
}
