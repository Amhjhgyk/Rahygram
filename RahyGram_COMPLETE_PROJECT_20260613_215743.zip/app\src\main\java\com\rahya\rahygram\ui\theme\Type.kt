package com.rahya.rahygram.ui.theme

import androidx.compose.material3.Typography

val RahyTypography = Typography()
