package com.rahya.rahygram.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightScheme = lightColorScheme(
    primary = PersianBlue,
    secondary = PersianGold,
    tertiary = Jade,
    background = Cream,
    surface = Mist,
    onPrimary = Cream,
    onSecondary = Charcoal,
    onBackground = Ink,
    onSurface = Ink
)

private val DarkScheme = darkColorScheme(
    primary = PersianGold,
    secondary = PersianBlue,
    tertiary = Jade,
    background = Charcoal,
    surface = Ink,
    onPrimary = Charcoal,
    onSecondary = Cream,
    onBackground = Cream,
    onSurface = Cream
)

@Composable
fun RahyGramTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkScheme else LightScheme,
        typography = RahyTypography,
        content = content
    )
}
