package com.rahya.rahygram.core.localization

import androidx.compose.ui.text.intl.Locale

data class LanguageOption(val tag: String, val localName: String)

val supportedLanguages = listOf(
    LanguageOption("fa", "فارسی"),
    LanguageOption("en", "English"),
    LanguageOption("ar", "العربية"),
    LanguageOption("tr", "Türkçe"),
    LanguageOption("ru", "Русский")
)

fun isRtlLanguage(tag: String): Boolean = tag == "fa" || tag == "ar"

fun currentLanguageTag(): String = Locale.current.language
