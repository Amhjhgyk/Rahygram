package com.rahya.rahygram.viewmodel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rahya.rahygram.data.model.Chat
import com.rahya.rahygram.data.model.ChatKind
import com.rahya.rahygram.data.model.Message
import com.rahya.rahygram.data.model.MessageType
import com.rahya.rahygram.data.model.Moment
import com.rahya.rahygram.data.model.User
import com.rahya.rahygram.data.repository.ServiceLocator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class HomeTab { All, Groups, Contacts }

class ChatViewModel : ViewModel() {
    private val repository = ServiceLocator.messagingRepository
    private val queryState = MutableStateFlow("")
    private val selectedTabState = MutableStateFlow(HomeTab.All)

    val chats: StateFlow<List<Chat>> = repository.chats.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val moments: StateFlow<List<Moment>> = repository.moments.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val contacts: StateFlow<List<User>> = repository.contacts.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val query: StateFlow<String> = queryState.asStateFlow()
    val selectedTab: StateFlow<HomeTab> = selectedTabState.asStateFlow()
    val filteredChats: StateFlow<List<Chat>> = combine(chats, queryState, selectedTabState) { chats, query, tab ->
        chats
            .filter { chat -> tab != HomeTab.Groups || chat.kind == ChatKind.Group }
            .filter { chat ->
                query.isBlank() ||
                    chat.title.contains(query, ignoreCase = true) ||
                    chat.lastMessage?.body?.contains(query, ignoreCase = true) == true
            }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun messages(chatId: String): Flow<List<Message>> = repository.messages(chatId)

    fun setQuery(value: String) {
        queryState.value = value
    }

    fun setTab(tab: HomeTab) {
        selectedTabState.value = tab
    }

    fun startDirectChat(contactId: String, onCreated: (String) -> Unit) = viewModelScope.launch {
        onCreated(repository.startDirectChat(contactId))
    }

    fun createGroup(title: String, memberIds: List<String>, onCreated: (String) -> Unit) = viewModelScope.launch {
        onCreated(repository.createGroup(title, memberIds))
    }

    fun sendText(chatId: String, text: String) = viewModelScope.launch {
        repository.sendText(chatId, text)
    }

    fun sendAttachment(chatId: String, uri: Uri, type: MessageType, fileName: String? = null) = viewModelScope.launch {
        repository.sendAttachment(chatId, uri, type, fileName)
    }

    fun react(chatId: String, messageId: String, reaction: String) = viewModelScope.launch {
        repository.react(chatId, messageId, reaction)
    }

    fun delete(chatId: String, messageId: String) = viewModelScope.launch {
        repository.deleteMessage(chatId, messageId)
    }

    fun edit(chatId: String, messageId: String, text: String) = viewModelScope.launch {
        repository.editMessage(chatId, messageId, text)
    }

    fun syncFcmToken(token: String) = viewModelScope.launch {
        repository.syncFcmToken(token)
    }
}
