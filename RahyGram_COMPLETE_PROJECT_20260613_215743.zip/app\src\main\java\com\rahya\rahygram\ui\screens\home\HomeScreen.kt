package com.rahya.rahygram.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.rahya.rahygram.R
import com.rahya.rahygram.data.model.Chat
import com.rahya.rahygram.data.model.Moment
import com.rahya.rahygram.data.model.User
import com.rahya.rahygram.ui.components.RahyAvatar
import com.rahya.rahygram.viewmodel.ChatViewModel
import com.rahya.rahygram.viewmodel.HomeTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: ChatViewModel,
    onOpenChat: (String) -> Unit,
    onOpenSettings: () -> Unit
) {
    val chats by viewModel.filteredChats.collectAsState()
    val moments by viewModel.moments.collectAsState()
    val contacts by viewModel.contacts.collectAsState()
    val query by viewModel.query.collectAsState()
    val selectedTab by viewModel.selectedTab.collectAsState()
    var showNewChat by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(stringResource(R.string.app_name), fontWeight = FontWeight.Black)
                        Text(stringResource(R.string.chats), style = MaterialTheme.typography.labelMedium)
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Rounded.Settings, contentDescription = stringResource(R.string.settings))
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { showNewChat = true }, containerColor = MaterialTheme.colorScheme.secondary) {
                Icon(Icons.Rounded.Add, contentDescription = stringResource(R.string.new_chat))
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize(),
            contentPadding = PaddingValues(bottom = 96.dp)
        ) {
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = viewModel::setQuery,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 18.dp, vertical = 8.dp),
                    leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                    placeholder = { Text(stringResource(R.string.search)) },
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp)
                )
            }
            item {
                HomeTabs(selectedTab = selectedTab, onSelect = viewModel::setTab)
            }
            item {
                AnimatedVisibility(selectedTab != HomeTab.Contacts) {
                    MomentRow(moments)
                }
            }
            if (selectedTab == HomeTab.Contacts) {
                items(contacts, key = { it.id }) { contact ->
                    ContactRow(
                        contact = contact,
                        onClick = {
                            viewModel.startDirectChat(contact.id) { chatId -> onOpenChat(chatId) }
                        }
                    )
                }
            } else {
                items(chats, key = { it.id }) { chat ->
                    ChatRow(chat = chat, onClick = { onOpenChat(chat.id) })
                }
            }
        }
    }

    if (showNewChat) {
        NewChatDialog(
            contacts = contacts,
            onDismiss = { showNewChat = false },
            onCreateGroup = {
                viewModel.createGroup("Rahy Group", contacts.map { it.id }) { chatId ->
                    showNewChat = false
                    onOpenChat(chatId)
                }
            },
            onContactSelected = { contact ->
                viewModel.startDirectChat(contact.id) { chatId ->
                    showNewChat = false
                    onOpenChat(chatId)
                }
            }
        )
    }
}

@Composable
private fun HomeTabs(selectedTab: HomeTab, onSelect: (HomeTab) -> Unit) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            FilterChip(
                selected = selectedTab == HomeTab.All,
                onClick = { onSelect(HomeTab.All) },
                label = { Text(stringResource(R.string.all_chats)) }
            )
        }
        item {
            FilterChip(
                selected = selectedTab == HomeTab.Groups,
                onClick = { onSelect(HomeTab.Groups) },
                leadingIcon = { Icon(Icons.Rounded.Group, contentDescription = null, modifier = Modifier.size(18.dp)) },
                label = { Text(stringResource(R.string.groups)) }
            )
        }
        item {
            FilterChip(
                selected = selectedTab == HomeTab.Contacts,
                onClick = { onSelect(HomeTab.Contacts) },
                leadingIcon = { Icon(Icons.Rounded.Person, contentDescription = null, modifier = Modifier.size(18.dp)) },
                label = { Text(stringResource(R.string.contacts)) }
            )
        }
    }
}

@Composable
private fun MomentRow(moments: List<Moment>) {
    Column(Modifier.padding(vertical = 10.dp)) {
        Text(
            text = stringResource(R.string.stories),
            modifier = Modifier.padding(horizontal = 20.dp),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(10.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(moments, key = { it.id }) { moment ->
                MomentCard(moment)
            }
        }
    }
}

@Composable
private fun MomentCard(moment: Moment) {
    Surface(
        modifier = Modifier.size(width = 118.dp, height = 138.dp),
        shape = RoundedCornerShape(20.dp),
        color = Color(moment.accent)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            RahyAvatar(moment.ownerName, Modifier.size(42.dp))
            Column {
                Text(moment.ownerName, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1)
                Text(moment.caption, color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.labelMedium, maxLines = 2)
            }
        }
    }
}

@Composable
private fun ChatRow(chat: Chat, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            RahyAvatar(chat.title)
            if (chat.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.secondary)
                )
            }
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(chat.title, fontWeight = FontWeight.Bold, maxLines = 1, modifier = Modifier.weight(1f))
                if (chat.isMuted) Text("•", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.45f))
            }
            Text(
                text = chat.lastMessage?.body ?: stringResource(R.string.no_messages_yet),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.62f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (chat.unreadCount > 0) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primary) {
                Text(
                    text = chat.unreadCount.toString(),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun ContactRow(contact: User, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RahyAvatar(contact.displayName)
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 14.dp)
        ) {
            Text(contact.displayName, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(
                text = if (contact.isOnline) stringResource(R.string.online) else contact.phoneNumber ?: stringResource(R.string.offline),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.62f),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun NewChatDialog(
    contacts: List<User>,
    onDismiss: () -> Unit,
    onCreateGroup: () -> Unit,
    onContactSelected: (User) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.new_chat)) },
        text = {
            LazyColumn(modifier = Modifier.height(320.dp)) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(onClick = onCreateGroup)
                            .padding(horizontal = 18.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            modifier = Modifier.size(48.dp),
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primary
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Group,
                                contentDescription = null,
                                modifier = Modifier.padding(12.dp),
                                tint = MaterialTheme.colorScheme.onPrimary
                            )
                        }
                        Text(
                            text = stringResource(R.string.new_group),
                            modifier = Modifier.padding(horizontal = 14.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                items(contacts, key = { it.id }) { contact ->
                    ContactRow(contact = contact, onClick = { onContactSelected(contact) })
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.close))
            }
        }
    )
}
