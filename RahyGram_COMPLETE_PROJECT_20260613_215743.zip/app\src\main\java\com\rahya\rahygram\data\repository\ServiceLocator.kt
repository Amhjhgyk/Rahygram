package com.rahya.rahygram.data.repository

import com.rahya.rahygram.BuildConfig
import com.rahya.rahygram.data.firebase.FirebaseMessagingRepository

object ServiceLocator {
    val messagingRepository: MessagingRepository by lazy {
        if (BuildConfig.USE_FIREBASE_BACKEND) FirebaseMessagingRepository() else DemoMessagingRepository()
    }
}
