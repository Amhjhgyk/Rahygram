package com.rahya.rahygram.data.model

enum class MessageType { Text, Image, Voice, File }
enum class DeliveryState { Sending, Sent, Delivered, Seen }
enum class ChatKind { Direct, Group }

data class User(
    val id: String,
    val displayName: String,
    val phoneNumber: String? = null,
    val email: String? = null,
    val avatarSeed: String = displayName,
    val isOnline: Boolean = false,
    val lastSeenEpochMillis: Long = 0L,
    val preferredLanguage: String = "fa"
)

data class Message(
    val id: String,
    val chatId: String,
    val senderId: String,
    val body: String,
    val type: MessageType = MessageType.Text,
    val attachmentUrl: String? = null,
    val createdAtEpochMillis: Long,
    val editedAtEpochMillis: Long? = null,
    val deliveryState: DeliveryState = DeliveryState.Sent,
    val reactions: Map<String, String> = emptyMap(),
    val encryptedPayload: String? = null
)

data class Chat(
    val id: String,
    val title: String,
    val kind: ChatKind,
    val participantIds: List<String>,
    val lastMessage: Message? = null,
    val unreadCount: Int = 0,
    val isMuted: Boolean = false
)

data class Moment(
    val id: String,
    val ownerName: String,
    val accent: Long,
    val caption: String
)
