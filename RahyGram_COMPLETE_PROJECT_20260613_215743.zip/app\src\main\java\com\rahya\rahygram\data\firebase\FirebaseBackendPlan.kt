package com.rahya.rahygram.data.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage

class FirebaseBackendPlan(
    val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    val storage: FirebaseStorage = FirebaseStorage.getInstance()
) {
    val users = firestore.collection(FirebaseSchema.USERS)
    val chats = firestore.collection(FirebaseSchema.CHATS)
    val groups = firestore.collection(FirebaseSchema.GROUPS)

    fun messages(chatId: String) = chats.document(chatId).collection(FirebaseSchema.MESSAGES)
    fun attachments(chatId: String) = storage.reference.child("attachments/$chatId")
    fun voiceNotes(chatId: String) = storage.reference.child("voice-notes/$chatId")
}
