package com.rahya.rahygram.data.repository

import android.content.Context
import android.provider.ContactsContract
import com.rahya.rahygram.data.model.User

class ContactSyncManager(private val context: Context) {
    fun readDeviceContacts(): List<User> {
        val contacts = mutableListOf<User>()
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection,
            null,
            null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        )?.use { cursor ->
            val nameIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val phoneIndex = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (cursor.moveToNext()) {
                val name = cursor.getString(nameIndex).orEmpty()
                val phone = cursor.getString(phoneIndex).orEmpty()
                if (name.isNotBlank() || phone.isNotBlank()) {
                    contacts += User(
                        id = "device:${phone.filter(Char::isDigit)}",
                        displayName = name.ifBlank { phone },
                        phoneNumber = phone
                    )
                }
            }
        }
        return contacts.distinctBy { it.phoneNumber }
    }
}
