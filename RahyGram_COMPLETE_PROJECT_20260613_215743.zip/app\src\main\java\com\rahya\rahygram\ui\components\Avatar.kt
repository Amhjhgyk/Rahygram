package com.rahya.rahygram.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rahya.rahygram.ui.theme.PersianGold

@Composable
fun RahyAvatar(name: String, modifier: Modifier = Modifier) {
    val colors = listOf(Color(0xFF1E88A8), PersianGold, Color(0xFF2A9D8F), Color(0xFFE76F51), Color(0xFF6C5CE7))
    val color = colors[kotlin.math.abs(name.hashCode()) % colors.size]
    Box(
        modifier = modifier
            .size(48.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(color),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = name.firstOrNull()?.toString().orEmpty(),
            color = Color.White,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
}
