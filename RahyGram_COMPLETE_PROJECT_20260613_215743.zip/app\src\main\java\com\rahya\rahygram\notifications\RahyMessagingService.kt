package com.rahya.rahygram.notifications

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class RahyMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        FcmTokenStore.latestToken = token
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        NotificationHelper.showMessage(
            context = this,
            title = message.notification?.title ?: message.data["title"] ?: getString(com.rahya.rahygram.R.string.app_name),
            body = message.notification?.body ?: message.data["body"].orEmpty()
        )
    }
}

object FcmTokenStore {
    var latestToken: String? = null
}
