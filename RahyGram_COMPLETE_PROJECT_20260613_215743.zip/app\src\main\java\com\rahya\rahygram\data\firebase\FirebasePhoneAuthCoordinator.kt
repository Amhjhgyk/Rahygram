package com.rahya.rahygram.data.firebase

import android.app.Activity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit

class FirebasePhoneAuthCoordinator(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private var verificationId: String? = null
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null

    fun requestCode(
        activity: Activity,
        phoneNumber: String,
        onCodeSent: () -> Unit,
        onVerifiedInstantly: suspend (PhoneAuthCredential) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                MainScope().let { scope ->
                    scope.launchSafely(onError) { onVerifiedInstantly(credential) }
                }
            }

            override fun onVerificationFailed(exception: FirebaseException) {
                onError(exception)
            }

            override fun onCodeSent(
                id: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                verificationId = id
                resendToken = token
                onCodeSent()
            }
        }

        PhoneAuthProvider.verifyPhoneNumber(
            PhoneAuthOptions.newBuilder(auth)
                .setPhoneNumber(phoneNumber)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(activity)
                .setCallbacks(callbacks)
                .build()
        )
    }

    suspend fun verifyCode(code: String) {
        val id = verificationId ?: error("Verification id is missing. Request an OTP code first.")
        val credential = PhoneAuthProvider.getCredential(id, code)
        signInWithCredential(credential)
    }

    suspend fun signInWithCredential(credential: PhoneAuthCredential) {
        auth.signInWithCredential(credential).await()
    }

    private fun CoroutineScope.launchSafely(
        onError: (Throwable) -> Unit,
        block: suspend () -> Unit
    ) {
        launch {
            runCatching { block() }.onFailure(onError)
        }
    }
}
