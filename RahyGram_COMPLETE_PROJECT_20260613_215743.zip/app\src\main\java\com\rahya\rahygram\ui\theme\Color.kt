package com.rahya.rahygram.ui.theme

import androidx.compose.ui.graphics.Color

val PersianBlue = Color(0xFF1E88A8)
val PersianGold = Color(0xFFD6A84F)
val Charcoal = Color(0xFF102027)
val Ink = Color(0xFF18242A)
val Cream = Color(0xFFFFFBF4)
val Mist = Color(0xFFEAF3F5)
val Coral = Color(0xFFE76F51)
val Jade = Color(0xFF2A9D8F)
