package com.rahya.rahygram.ui.screens.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.rahya.rahygram.R
import com.rahya.rahygram.core.localization.currentLanguageTag
import com.rahya.rahygram.core.localization.supportedLanguages
import com.rahya.rahygram.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    onLoggedOut: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null)
                    }
                },
                title = { Text(stringResource(R.string.settings), fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(horizontal = 18.dp)
        ) {
            item {
                Spacer(Modifier.height(10.dp))
                SettingsSection(
                    icon = { Icon(Icons.Rounded.Language, contentDescription = null) },
                    title = stringResource(R.string.language)
                ) {
                    LazyRow(Modifier.fillMaxWidth()) {
                        items(supportedLanguages, key = { it.tag }) { language ->
                            FilterChip(
                                selected = currentLanguageTag() == language.tag,
                                onClick = { viewModel.setLanguage(language.tag) },
                                label = { Text(language.localName) },
                                modifier = Modifier.padding(end = 8.dp)
                            )
                        }
                    }
                }
            }
            item {
                SettingsSection(
                    icon = { Icon(Icons.Rounded.DarkMode, contentDescription = null) },
                    title = stringResource(R.string.theme)
                ) {
                    Text(stringResource(R.string.theme_system_note))
                }
            }
            item {
                SettingsSection(
                    icon = { Icon(Icons.Rounded.Security, contentDescription = null) },
                    title = stringResource(R.string.security)
                ) {
                    Text(stringResource(R.string.encryption_ready))
                }
            }
            item {
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        viewModel.logout()
                        onLoggedOut()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(stringResource(R.string.logout))
                }
            }
        }
    }
}

@Composable
private fun SettingsSection(
    icon: @Composable () -> Unit,
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface
    ) {
        ListItem(
            headlineContent = { Text(title, fontWeight = FontWeight.Bold) },
            supportingContent = {
                Column(Modifier.padding(top = 10.dp)) { content() }
            },
            leadingContent = { Column(horizontalAlignment = Alignment.CenterHorizontally) { icon() } }
        )
    }
}
