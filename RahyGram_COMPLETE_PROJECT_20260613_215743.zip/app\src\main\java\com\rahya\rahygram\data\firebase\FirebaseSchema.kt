package com.rahya.rahygram.data.firebase

object FirebaseSchema {
    const val USERS = "users"
    const val CHATS = "chats"
    const val GROUPS = "groups"
    const val MESSAGES = "messages"

    object UserFields {
        const val DISPLAY_NAME = "displayName"
        const val PHONE_NUMBER = "phoneNumber"
        const val EMAIL = "email"
        const val IS_ONLINE = "isOnline"
        const val LAST_SEEN = "lastSeenEpochMillis"
        const val FCM_TOKEN = "fcmToken"
        const val PUBLIC_IDENTITY_KEY = "publicIdentityKey"
    }

    object ChatFields {
        const val KIND = "kind"
        const val PARTICIPANTS = "participantIds"
        const val CREATED_AT = "createdAtEpochMillis"
        const val UPDATED_AT = "updatedAtEpochMillis"
        const val LAST_MESSAGE = "lastMessage"
    }

    fun messagesPath(chatId: String): String = "$CHATS/$chatId/$MESSAGES"
}
