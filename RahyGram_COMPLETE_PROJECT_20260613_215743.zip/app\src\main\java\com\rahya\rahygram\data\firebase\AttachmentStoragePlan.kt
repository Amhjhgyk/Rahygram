package com.rahya.rahygram.data.firebase

import android.net.Uri
import com.google.firebase.storage.StorageReference

class AttachmentStoragePlan(private val backend: FirebaseBackendPlan = FirebaseBackendPlan()) {
    fun imageRef(chatId: String, messageId: String): StorageReference {
        return backend.attachments(chatId).child("images/$messageId")
    }

    fun fileRef(chatId: String, messageId: String, fileName: String): StorageReference {
        return backend.attachments(chatId).child("files/$messageId/$fileName")
    }

    fun voiceRef(chatId: String, messageId: String): StorageReference {
        return backend.voiceNotes(chatId).child("$messageId.m4a")
    }

    fun uploadTask(ref: StorageReference, uri: Uri) = ref.putFile(uri)
}
