package com.rahya.rahygram.ui.screens.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.rahya.rahygram.R
import com.rahya.rahygram.viewmodel.AuthViewModel

@Composable
fun AuthScreen(
    viewModel: AuthViewModel,
    onAuthenticated: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val user by viewModel.currentUser.collectAsState()
    val activity = LocalContext.current.findActivity()

    LaunchedEffect(user) {
        if (user != null) onAuthenticated()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(MaterialTheme.colorScheme.background, MaterialTheme.colorScheme.surface)
                )
            )
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            modifier = Modifier.size(76.dp),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.primary
        ) {
            Icon(
                imageVector = Icons.Rounded.Lock,
                contentDescription = null,
                modifier = Modifier.padding(18.dp),
                tint = MaterialTheme.colorScheme.onPrimary
            )
        }
        Spacer(Modifier.height(28.dp))
        Text(
            text = stringResource(R.string.app_name),
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Black
        )
        Text(
            text = stringResource(R.string.tagline),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )
        Spacer(Modifier.height(32.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(
                selected = !state.useEmail,
                onClick = { if (state.useEmail) viewModel.toggleLoginMode() },
                label = { Text(stringResource(R.string.phone_login)) }
            )
            FilterChip(
                selected = state.useEmail,
                onClick = { if (!state.useEmail) viewModel.toggleLoginMode() },
                label = { Text(stringResource(R.string.email_login)) }
            )
        }
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(
            value = state.identifier,
            onValueChange = viewModel::setIdentifier,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(if (state.useEmail) stringResource(R.string.email) else stringResource(R.string.phone_number)) },
            keyboardOptions = KeyboardOptions(keyboardType = if (state.useEmail) KeyboardType.Email else KeyboardType.Phone),
            shape = RoundedCornerShape(18.dp)
        )
        AnimatedVisibility(state.codeRequested) {
            OutlinedTextField(
                value = state.otp,
                onValueChange = viewModel::setOtp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                singleLine = true,
                label = { Text(stringResource(R.string.otp_code)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(18.dp)
            )
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { if (state.codeRequested) viewModel.verify() else viewModel.requestOtp(activity) },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp),
            shape = RoundedCornerShape(18.dp),
            enabled = state.identifier.isNotBlank() && !state.isLoading
        ) {
            Text(if (state.codeRequested) stringResource(R.string.verify) else stringResource(R.string.send_code))
        }
        Spacer(Modifier.height(16.dp))
        Text(
            text = stringResource(R.string.demo_code_hint),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f),
            modifier = Modifier.align(Alignment.CenterHorizontally)
        )
        state.errorMessage?.let { error ->
            Spacer(Modifier.height(10.dp))
            Text(
                text = error,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
