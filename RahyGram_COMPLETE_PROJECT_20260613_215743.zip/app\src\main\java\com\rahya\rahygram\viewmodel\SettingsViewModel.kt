package com.rahya.rahygram.viewmodel

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.rahya.rahygram.data.repository.ServiceLocator
import kotlinx.coroutines.launch

class SettingsViewModel : ViewModel() {
    private val repository = ServiceLocator.messagingRepository

    fun setLanguage(tag: String) {
        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag))
    }

    fun logout() = viewModelScope.launch {
        repository.signOut()
    }
}
