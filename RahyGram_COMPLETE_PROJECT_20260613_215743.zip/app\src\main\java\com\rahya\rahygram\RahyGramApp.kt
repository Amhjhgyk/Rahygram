package com.rahya.rahygram

import android.app.Application
import com.rahya.rahygram.notifications.NotificationHelper

class RahyGramApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.ensureChannels(this)
    }
}
