package com.rahya.rahygram.data.repository

import android.net.Uri
import com.rahya.rahygram.data.model.Chat
import com.rahya.rahygram.data.model.ChatKind
import com.rahya.rahygram.data.model.DeliveryState
import com.rahya.rahygram.data.model.Message
import com.rahya.rahygram.data.model.MessageType
import com.rahya.rahygram.data.model.Moment
import com.rahya.rahygram.data.model.User
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import java.util.UUID

interface MessagingRepository {
    val currentUser: Flow<User?>
    val chats: Flow<List<Chat>>
    val moments: Flow<List<Moment>>
    val contacts: Flow<List<User>>

    suspend fun signInWithOtp(identifier: String, code: String)
    suspend fun requestOtp(identifier: String)
    suspend fun signOut()
    fun messages(chatId: String): Flow<List<Message>>
    suspend fun startDirectChat(contactId: String): String
    suspend fun createGroup(title: String, memberIds: List<String>): String
    suspend fun sendText(chatId: String, text: String)
    suspend fun sendAttachment(chatId: String, uri: Uri, type: MessageType, fileName: String? = null)
    suspend fun deleteMessage(chatId: String, messageId: String)
    suspend fun editMessage(chatId: String, messageId: String, newText: String)
    suspend fun react(chatId: String, messageId: String, reaction: String)
    suspend fun syncFcmToken(token: String)
}

class DemoMessagingRepository : MessagingRepository {
    private val me = User(
        id = "u-me",
        displayName = "سارا رحیمی",
        phoneNumber = "+98 912 000 0000",
        isOnline = true
    )

    private val users = listOf(
        me,
        User("u-arya", "آریا نیک", "+98 912 123 4567", isOnline = true),
        User("u-niloofar", "نیلوفر", "+98 935 333 2211", isOnline = false),
        User("u-hamdam", "گروه همدم", isOnline = true)
    )

    private val currentUserState = MutableStateFlow<User?>(null)
    private val chatState = MutableStateFlow(
        listOf(
            Chat(
                id = "c-arya",
                title = "آریا نیک",
                kind = ChatKind.Direct,
                participantIds = listOf("u-me", "u-arya"),
                unreadCount = 2
            ),
            Chat(
                id = "c-team",
                title = "تیم راهی",
                kind = ChatKind.Group,
                participantIds = listOf("u-me", "u-arya", "u-niloofar"),
                unreadCount = 0
            ),
            Chat(
                id = "c-niloofar",
                title = "نیلوفر",
                kind = ChatKind.Direct,
                participantIds = listOf("u-me", "u-niloofar"),
                unreadCount = 0
            )
        )
    )

    private val messageState = MutableStateFlow(
        mapOf(
            "c-arya" to listOf(
                Message("m1", "c-arya", "u-arya", "سلام، نسخه اولیه راهی‌گرام خیلی تمیز شده.", createdAtEpochMillis = nowMinus(12)),
                Message("m2", "c-arya", "u-me", "مرسی. حباب‌های چت را متفاوت و اختصاصی طراحی کردم.", createdAtEpochMillis = nowMinus(9), deliveryState = DeliveryState.Seen),
                Message("m3", "c-arya", "u-arya", "برای OTP هم Firebase Auth آماده است؟", createdAtEpochMillis = nowMinus(4))
            ),
            "c-team" to listOf(
                Message("m4", "c-team", "u-niloofar", "فایل طراحی لحظه‌ها را بارگذاری کردم.", createdAtEpochMillis = nowMinus(30)),
                Message("m5", "c-team", "u-me", "عالیه. بعد از اتصال Storage، آپلود واقعی را فعال می‌کنیم.", createdAtEpochMillis = nowMinus(24), deliveryState = DeliveryState.Delivered)
            ),
            "c-niloofar" to listOf(
                Message("m6", "c-niloofar", "u-niloofar", "امشب نسخه RTL را تست می‌کنم.", createdAtEpochMillis = nowMinus(70))
            )
        )
    )

    init {
        refreshLastMessages()
    }

    override val currentUser: Flow<User?> = currentUserState
    override val chats: Flow<List<Chat>> = chatState
    override val moments: Flow<List<Moment>> = MutableStateFlow(
        listOf(
            Moment("s1", "آریا", 0xFFD6A84F, "طراحی تازه"),
            Moment("s2", "نیلوفر", 0xFF1E88A8, "تست RTL"),
            Moment("s3", "تیم", 0xFF6C5CE7, "انتشار داخلی")
        )
    )
    override val contacts: Flow<List<User>> = MutableStateFlow(users.filterNot { it.id == me.id })

    override suspend fun requestOtp(identifier: String) = Unit

    override suspend fun signInWithOtp(identifier: String, code: String) {
        currentUserState.value = me.copy(phoneNumber = identifier.ifBlank { me.phoneNumber })
    }

    override suspend fun signOut() {
        currentUserState.value = null
    }

    override fun messages(chatId: String): Flow<List<Message>> {
        return messageState.map { it[chatId].orEmpty() }
    }

    override suspend fun startDirectChat(contactId: String): String {
        val existing = chatState.value.firstOrNull {
            it.kind == ChatKind.Direct && contactId in it.participantIds
        }
        if (existing != null) return existing.id

        val contact = users.firstOrNull { it.id == contactId } ?: return chatState.value.first().id
        val chatId = "c-${contact.id.removePrefix("u-")}"
        val chat = Chat(
            id = chatId,
            title = contact.displayName,
            kind = ChatKind.Direct,
            participantIds = listOf(me.id, contact.id)
        )
        chatState.update { listOf(chat) + it }
        messageState.update { it + (chatId to emptyList()) }
        return chatId
    }

    override suspend fun createGroup(title: String, memberIds: List<String>): String {
        val chatId = "g-${UUID.randomUUID()}"
        val chat = Chat(
            id = chatId,
            title = title.ifBlank { "Rahy Group" },
            kind = ChatKind.Group,
            participantIds = (memberIds + me.id).distinct()
        )
        chatState.update { listOf(chat) + it }
        messageState.update { it + (chatId to emptyList()) }
        return chatId
    }

    override suspend fun sendText(chatId: String, text: String) {
        if (text.isBlank()) return
        val message = Message(
            id = UUID.randomUUID().toString(),
            chatId = chatId,
            senderId = me.id,
            body = text.trim(),
            createdAtEpochMillis = System.currentTimeMillis(),
            deliveryState = DeliveryState.Sent,
            encryptedPayload = "encrypted:${text.hashCode()}"
        )
        messageState.update { all -> all + (chatId to (all[chatId].orEmpty() + message)) }
        refreshLastMessages()
    }

    override suspend fun sendAttachment(chatId: String, uri: Uri, type: MessageType, fileName: String?) {
        val label = when (type) {
            MessageType.Image -> "Image"
            MessageType.Voice -> "Voice note"
            MessageType.File -> fileName ?: "File"
            MessageType.Text -> "Attachment"
        }
        val message = Message(
            id = UUID.randomUUID().toString(),
            chatId = chatId,
            senderId = me.id,
            body = label,
            type = type,
            attachmentUrl = uri.toString(),
            createdAtEpochMillis = System.currentTimeMillis(),
            deliveryState = DeliveryState.Sent
        )
        messageState.update { all -> all + (chatId to (all[chatId].orEmpty() + message)) }
        refreshLastMessages()
    }

    override suspend fun deleteMessage(chatId: String, messageId: String) {
        messageState.update { all -> all + (chatId to all[chatId].orEmpty().filterNot { it.id == messageId }) }
        refreshLastMessages()
    }

    override suspend fun editMessage(chatId: String, messageId: String, newText: String) {
        messageState.update { all ->
            all + (chatId to all[chatId].orEmpty().map {
                if (it.id == messageId) it.copy(body = newText, editedAtEpochMillis = System.currentTimeMillis()) else it
            })
        }
        refreshLastMessages()
    }

    override suspend fun react(chatId: String, messageId: String, reaction: String) {
        messageState.update { all ->
            all + (chatId to all[chatId].orEmpty().map {
                if (it.id == messageId) it.copy(reactions = it.reactions + (me.id to reaction)) else it
            })
        }
    }

    override suspend fun syncFcmToken(token: String) = Unit

    private fun refreshLastMessages() {
        val messages = messageState.value
        chatState.update { chats ->
            chats.map { chat -> chat.copy(lastMessage = messages[chat.id]?.maxByOrNull { it.createdAtEpochMillis }) }
        }
    }

    private companion object {
        fun nowMinus(minutes: Long): Long = System.currentTimeMillis() - minutes * 60_000
    }
}
